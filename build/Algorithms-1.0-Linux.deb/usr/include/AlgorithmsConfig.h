#define Algorithms_VERSION_MAJOR 
#define Algorithms_VERSION_MINOR 
